﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using RAEE.Comun.Clases;
using RAEE.Comun;
/// <summary>
/// Página para la gestión de usuarios de GUAI
/// </summary>
public partial class RAEE_Administracion_GestionUsuarios : PageBase
{
    #region Propiedades
    /// <summary>
    /// Mensaje de error generado
    /// </summary>
    private string _MensajeError = string.Empty;
    /// <summary>
    /// Clase de negocio para todo lo relacionado con productos (Categorías, subcategorías)
    /// </summary>
    private GUAI.Neg.NegPersona _negocio;
    /// <summary>
    /// Clase de negocio para todo lo relacionado con productos (Categorías, subcategorías)
    /// </summary>
    private GUAI.Neg.NegPersona NegocioPersona
    {
        get 
        {
            if (_negocio == null)
                _negocio = new GUAI.Neg.NegPersona();
            return _negocio;
        }
    }

    /// <summary>
    /// Propiedad de la expresión de la ordenación
    /// </summary>
    public string SortExpression
    {
        get { return (ViewState["SortExpression"] == null ? string.Empty : ViewState["SortExpression"].ToString()); }
        set { ViewState["SortExpression"] = value; }
    }
    /// <summary>
    /// Propiedad del sentido de la ordenación
    /// </summary>
    public string SortDirection
    {
        get { return (ViewState["SortDirection"] == null ? string.Empty : ViewState["SortDirection"].ToString()); }
        set { ViewState["SortDirection"] = value; }
    }

    /// <summary>
    /// Filtro guardado en sesión para conservar las búsquedas al volver de un detalle
    /// </summary>
    private FiltroGestorUsuario FiltroInicial
    {
        get { return (Session[TipoDatos.FiltroAplicacion] == null) ? null : (FiltroGestorUsuario)Session[TipoDatos.FiltroAplicacion]; }
        set { Session[TipoDatos.FiltroAplicacion] = value; }
    }

    #endregion

    #region Eventos
    /// <summary>
    /// configuración inicial al cargar la página
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                LimpiarSesion();
                CargarTipoDocumento();
                CargarGruposUsuarios();
                ucOrganizaciones.Limpiar();
                ucOrganizaciones.Habilitado = false;
                if (FiltroInicial != null)
                    CargarFiltro();
                CargarGrid();
            }

            if (MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                dvOrganizacion.Visible = false;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".Page_Load()", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Limpia el filtro establecido dejando los valores iniciales
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLimpiar_Click(object sender, EventArgs e)
    {
        try
        {
            gridPaginacion.Paginacion.PaginaActual = 1;
            gridPaginacion.Paginacion.RegistroInicial = 0;
            ddTipoDoc.ClearSelection();
            tbDocumento.Text = string.Empty;
            tbNombre.Text = string.Empty;
            tbApellido1.Text = string.Empty;
            tbApellido2.Text = string.Empty;
            ddGrupoUsuario.ClearSelection();
            ucOrganizaciones.Limpiar();
            ucOrganizaciones.Habilitado = false;

            Session.Remove(TipoDatos.FiltroAplicacion);

            gridPaginacion.Paginacion.CampoOrdenacion = "NOMBRE_COMPLETO";
            SortExpression = "NOMBRE_COMPLETO";
            gridPaginacion.Paginacion.Orden = PaginacionCls.Asc;
            SortDirection = PaginacionCls.Asc;
            CargarGrid();
            //SRS: Ya se actualiza la paginación al ActualizarLiterales dentro de la carga del grid
            //gridPaginacion.ActualizarPaginacion();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnLimpiar_Click()", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Filtra el listado por los valores introducidos
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnFiltrar_Click(object sender, EventArgs e)
    {
        try
        {
            gridPaginacion.Paginacion.PaginaActual = 1;
            gridPaginacion.Paginacion.RegistroInicial = 0;
            if (FiltroInicial != null)
                FiltroInicial.Paginacion = gridPaginacion.Paginacion;
            CargarGrid();
            //SRS: Ya se actualiza la paginación al ActualizarLiterales dentro de la carga del grid
            //gridPaginacion.ActualizarPaginacion();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnFiltrar_click(). Ha ocurrido un error al filtrar el grid de gestión de usuarios", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Función que controla que el filtro permanezca visible o colapsado
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Colapsar(object sender, ImageClickEventArgs e)
    {
        try
        {
            bool colapsado;
            if (ViewState["FiltroColapsado"] != null)
            {
                colapsado = (bool)ViewState["FiltroColapsado"];
                colapsado = !colapsado;
                ViewState["FiltroColapsado"] = colapsado;
            }
            else
            {
                colapsado = false;
                ViewState["FiltroColapsado"] = false;
            }

            if (colapsado)
            {
                dvFiltro.Attributes["class"] = "cajafichadatos cajafiltro hide";
                //dvGrid.Attributes["class"] = "formulario gridSinFiltro";
                buttonExpander.ImageUrl = "~/Content/Imagenes/expand.jpg";
            }
            else
            {
                dvFiltro.Attributes["class"] = "cajafichadatos cajafiltro";
                //if (MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                //    //dvGrid.Attributes["class"] = "gridUsuariosConFiltroExt3";
                //else
                //    //dvGrid.Attributes["class"] = "formulario gridUsuariosConFiltro3";
                buttonExpander.ImageUrl = "~/Content/Imagenes/collapse.jpg";
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".Colapsar()", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Evento generado cuando se selecciona un grupo de usuario. Se carga la lista de organizaciones vinculadas
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddGrupoUsuario_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ucOrganizaciones.Limpiar();
            if (!string.IsNullOrEmpty(ddGrupoUsuario.SelectedValue))
            {
                ucOrganizaciones.Habilitado = true;
                CargarOrganizaciones();
            }
            else
                ucOrganizaciones.Habilitado = false;
            ddGrupoUsuario.Focus();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".ddGrupoUsuario_SelectedIndex()", ex);
            Error(_MensajeError);
        }
    }
    #endregion

    #region Eventos del grid
    /// <summary>
    /// Recarga el grid después de la paginación.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gridPaginacion_RecargarGrid(object sender, EventArgs e)
    {
        try
        {
            FiltroInicial.Paginacion = gridPaginacion.Paginacion;
            CargarGrid();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".gridPaginacion_RecargarGrid()", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Procedimiento de la grid, al crear una fila
    /// </summary>
    protected void gvGestionUsuarios_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.background='#FFF0A2'");
                e.Row.Attributes.Add("onmouseout", "this.style.background='#FFFFFF'");
            }
            if (e.Row.RowType == DataControlRowType.Header)
            {
                string[] auxValores = new string[2] { "IDENTIFICACION", "NOMBRE_COMPLETO" };

                string[] auxTooltip = new string[2] { "Ordena por el número de documento", "Ordena por el nombre completo" };
                for (int i = 0; i < auxValores.Length; i++)
                {
                    if (SortExpression.ToUpper().Trim() == auxValores[i] ||
                        (FiltroInicial.Paginacion != null && FiltroInicial.Paginacion.CampoOrdenacion.Trim() == auxValores[i]))
                    {
                        using (System.Web.UI.HtmlControls.HtmlGenericControl span = new System.Web.UI.HtmlControls.HtmlGenericControl())
                        {
                            if (FiltroInicial.Paginacion != null && !string.IsNullOrEmpty(FiltroInicial.Paginacion.CampoOrdenacion))
                            {
                                SortExpression = FiltroInicial.Paginacion.CampoOrdenacion;
                                SortDirection = FiltroInicial.Paginacion.Orden;
                            }

                            if (SortDirection == PaginacionCls.Asc)
                                span.Attributes["class"] = "glyphicon glyphicon-arrow-up";
                            else
                                span.Attributes["class"] = "glyphicon glyphicon-arrow-down";

                            span.Attributes["aria-hidden"] = "true";
                            span.ID = "ico1";
                            // Añadir icono a la cabecera
                            e.Row.Cells[i + 2].Controls.AddAt(0, span);
                        }
                    }
                    e.Row.Cells[i + 2].ToolTip = auxTooltip[i];
                }
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".gvGestionUsuarios_RowCreated()", ex);
            Error(_MensajeError);
        }
    }
    /// <summary>
    /// Procedimiento de la grid, al ejecutar un comando
    /// </summary>
    protected void gvGestionUsuarios_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (gvGestionUsuarios.Rows.Count > 0)
        {
            switch (e.CommandName)
            {
                case "Detalle":
                    //Recuperamos el identificador de la persona
                    Session["IdPersonaDetalle"] = e.CommandArgument.ToString();
                    Response.Redirect(MasterBase.RelativeURL + "UI/Administracion/ModificarUsuario.aspx?grid=S", false);
                    break;
            }
        }
    }
    /// <summary>
    /// Procedimiento de la grid, ordenación de los datos
    /// </summary>
    protected void gvGestionUsuarios_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            SortDirection = GetSortDirection(e.SortExpression).Equals("Ascending") ? PaginacionCls.Asc : PaginacionCls.Desc;
            SortExpression = e.SortExpression;

            gridPaginacion.Paginacion.PaginaActual = 1;            
            gridPaginacion.Paginacion.RegistroInicial = 0;
            gridPaginacion.Paginacion.CampoOrdenacion = ViewState["SortExpression"].ToString();
            gridPaginacion.Paginacion.Orden = ViewState["SortDirection"].ToString();
            FiltroInicial.Paginacion = gridPaginacion.Paginacion;
            CargarGrid();
            //SRS: Ya se actualiza la paginación al ActualizarLiterales dentro de la carga del grid
            //gridPaginacion.ActualizarPaginacion();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".gvGestionUsuarios_Sorting()", ex);
            Error(_MensajeError);
        }
    }
    #endregion

    #region Métodos privados
    /// <summary>
    /// Carga el combo de tipo documento para la persona
    /// </summary>
    private void CargarTipoDocumento()
    {
        try
        {
            DllUtils.CodigosInadm codigos = new DllUtils.CodigosInadm();
            DataTable dt = new DataTable();
            dt = codigos.GetTiposDoc();

            System.Data.DataView dv = dt.DefaultView;
            dv.Sort = "CTIPO_DOC ASC";

            ddTipoDoc.DataSource = dv;
            ddTipoDoc.DataBind();

            //añado como primer elemento texto
            ddTipoDoc.Items.Insert(0, new ListItem("Elija una opción", ""));
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarTipoDocumento()", ex);
            _MensajeError = "Error al cargar los tipos de documento";
            throw;
        }
    }
    /// <summary>
    /// Carga el combo de grupos usuarios. Si es extranet se cargará con el grupo usuario con el que se haya logado
    /// </summary>
    private void CargarGruposUsuarios()
    {
        try
        {
            if (MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Intranet.GetHashCode().ToString())
            {
                GUAI.Neg.NegGestionPermisos negocio = new GUAI.Neg.NegGestionPermisos();
                DataTable dtGruposUsuario = new DataTable();
                dtGruposUsuario = negocio.GetGruposUsuarioDatos(MasterBase.DatosSesionLogin.Perfil.IdAplicacion, null);
                if (dtGruposUsuario != null)
                {
                    ddGrupoUsuario.DataSource = dtGruposUsuario;
                    ddGrupoUsuario.DataBind();
                    //añado como primer elemento texto
                    ddGrupoUsuario.Items.Insert(0, new ListItem("Elija una opción", ""));
                }
            }
        }
        catch(Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarGruposUsuarios()", ex);
            _MensajeError = "Error al cargar los grupos de usuario";
            throw;
        }
    }
    /// <summary>
    /// Carga la lista de organizaciones 
    /// </summary>
    private void CargarOrganizaciones()
    {
        try
        {
            if (MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString() && MasterBase.DatosSesionLogin.Perfil.GrupoUsuario.Codigo != RAEE.Comun.TipoDatos.GrupoUsuario.SCR.ToString())
            {
                ucOrganizaciones.IdOrganizacion = (int)MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion;
                ucOrganizaciones.Habilitado = false;
            }
            else
            {
                ucOrganizaciones.IdGrupoUsuario = long.Parse(ddGrupoUsuario.SelectedValue);
                ucOrganizaciones.Iniciar();
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarOrganizaciones(). Grupo usuario: " + ddGrupoUsuario.SelectedValue, ex);
            _MensajeError = "No se han podido cargar la lista de organizaciones";
            throw;
        }
    }
    /// <summary>
    /// Se carga el grid con la lista de usuarios
    /// </summary>
    private void CargarGrid()
    {
        try
        {
            PaginacionCls paginacion = gridPaginacion.Paginacion;
            GUAI.Ent.Clases.FiltroUsuarioCls filtro = new GUAI.Ent.Clases.FiltroUsuarioCls();
           
            DataTable dtPersonas = new DataTable();

            filtro = SetFiltro();

            if (string.IsNullOrEmpty(paginacion.CampoOrdenacion))
            {
                paginacion.CampoOrdenacion = "NOMBRE_COMPLETO";
                SortExpression = "NOMBRE_COMPLETO";
                paginacion.Orden = PaginacionCls.Asc;
                SortDirection = PaginacionCls.Asc;
            }

            filtro.CampoOrdenacion = paginacion.CampoOrdenacion;
            filtro.Orden = (paginacion.Orden == PaginacionCls.Asc) ? GUAI.Recursos.Tipos.eTipoOrdenacion.ASC : GUAI.Recursos.Tipos.eTipoOrdenacion.DESC;
            filtro.RegIni = paginacion.RegistroInicial + 1;
            filtro.RegFin = (paginacion.RegistroInicial + paginacion.RegistrosPorPagina);

            dtPersonas = NegocioPersona.GetPersonasFiltro(filtro);
            
            gridPaginacion.Paginacion = paginacion;

            if (dtPersonas != null)
                gvGestionUsuarios.DataSource = dtPersonas.DefaultView;
            else
                gvGestionUsuarios.DataSource = null;

            gvGestionUsuarios.DataBind();

            paginacion.NumeroRegistrosTotales = filtro.NumReg;

            gridPaginacion.MostrarPaginacion = paginacion.NumeroRegistrosTotales > 0; //Mostramos u ocultamos la paginación dependiendo del resultado del grid.            

            gridPaginacion.ActualizarLiterales();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarGrid()", ex);
            _MensajeError = "Error al cargar el listado de usuarios";
            throw;
        }
    }
    /// <summary>
    /// Limpia las variables de sesión utilizadas
    /// </summary>
    private void LimpiarSesion()
    {
        Session.Remove("IdPersonaDetalle");
        Session.Remove("LoginUsuario");
    }
    /// <summary>
    /// Genera el filtro a partir de los controles de filtrado
    /// </summary>
    private GUAI.Ent.Clases.FiltroUsuarioCls SetFiltro()
    {
        GUAI.Ent.Clases.FiltroUsuarioCls filtroGUAI = new GUAI.Ent.Clases.FiltroUsuarioCls();
        FiltroGestorUsuario filtro = new FiltroGestorUsuario();
        try
        {
            filtro.Vacio = true;

            if (!string.IsNullOrEmpty(tbNombre.Text))
            {
                filtro.Vacio = false;
                filtro.Nombre = tbNombre.Text.Trim();
            }

            if (!string.IsNullOrEmpty(tbApellido1.Text))
            {
                filtro.Vacio = false;
                filtro.Apellido1 = tbApellido1.Text.Trim();
            }

            if (!string.IsNullOrEmpty(tbApellido2.Text))
            {
                filtro.Vacio = false;
                filtro.Apellido2 = tbApellido2.Text.Trim();
            }

            if (ddTipoDoc.SelectedIndex > 0)
            {
                filtro.Vacio = false;
                filtro.TipoDocumento = ddTipoDoc.SelectedValue;
            }

            if (!string.IsNullOrEmpty(tbDocumento.Text))
            {
                filtro.Vacio = false;
                filtro.Documento = tbDocumento.Text.Trim();
            }


            if (MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
            {
                filtro.IdOrganizacion = MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion;
                filtro.IdGrupoUsuario = MasterBase.DatosSesionLogin.Perfil.GrupoUsuario.IdGrupoUsuario;
            }
            else
            {
                if (ddGrupoUsuario.SelectedIndex != 0)
                {
                    filtro.Vacio = false;
                    filtro.IdGrupoUsuario = long.Parse(ddGrupoUsuario.SelectedValue);
                }
                if (ucOrganizaciones.IdOrganizacion > 0)
                {
                    filtro.Vacio = false;
                    filtro.IdOrganizacion = ucOrganizaciones.IdOrganizacion;
                    filtro.NombreOrganizacion = ucOrganizaciones.GetNombreOrganizacion();
                }
                else if (!string.IsNullOrEmpty(ucOrganizaciones.GetNombreOrganizacion()))
                {
                    filtro.Vacio = true;
                    filtro.NombreOrganizacion = ucOrganizaciones.GetNombreOrganizacion();
                }
            }
            if (!filtro.Vacio)
                imgCirculo.ImageUrl = "~/Content/Imagenes/green_circle.JPG";
            else
            {
                if (FiltroInicial != null & !IsPostBack)
                    CargarFiltro();
                else
                    imgCirculo.ImageUrl = "~/Content/Imagenes/gray_circle.JPG";
            }

            if (FiltroInicial != null)
                filtro.Paginacion = FiltroInicial.Paginacion;

            filtro.Pagina = this.GetType().Name;
            FiltroInicial = filtro;

            filtroGUAI.TipoDocumentoUsuario = filtro.TipoDocumento;
            filtroGUAI.NumDocumentoUsuario = filtro.Documento;
            filtroGUAI.NombreUsuario = filtro.Nombre;
            filtroGUAI.Apellido1 = filtro.Apellido1;
            filtroGUAI.Apellido2 = filtro.Apellido2;
            filtroGUAI.Aplicaciones = new List<long>() { RAEE.Comun.TipoDatos.Aplicacion };
            filtroGUAI.IdGrupoUsuario = filtro.IdGrupoUsuario;
            filtroGUAI.IdOrganizacion = filtro.IdOrganizacion;
            filtroGUAI.NombreOrganizacion = filtro.NombreOrganizacion;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".SetFiltro(). Descripcion; ", ex);
            _MensajeError = "Ha ocurrido un error al establecer el filtro de la página";
            throw;
        }
        return filtroGUAI;
    }
    /// <summary>
    /// Asigna los valores del filtro en función de lo que venga de sesion
    /// </summary>
    private void CargarFiltro()
    {
        FiltroGestorUsuario filtro = FiltroInicial;
        try
        {
            if (!string.IsNullOrEmpty(filtro.TipoDocumento))
                ddTipoDoc.SelectedValue = filtro.TipoDocumento;

            if (!string.IsNullOrEmpty(filtro.Documento))
                tbDocumento.Text = filtro.Documento;

            if (!string.IsNullOrEmpty(filtro.Nombre))
                tbNombre.Text = filtro.Nombre;

            if (!string.IsNullOrEmpty(filtro.Apellido1))
                tbApellido1.Text = filtro.Apellido1;

            if (!string.IsNullOrEmpty(filtro.Apellido2))
                tbApellido2.Text = filtro.Apellido2;

            if (filtro.IdGrupoUsuario > 0)
            {
                ddGrupoUsuario.SelectedValue = filtro.IdGrupoUsuario.ToString();
                ucOrganizaciones.Habilitado = true;
            }

            if (filtro.IdOrganizacion > 0)
            {
                ucOrganizaciones.IdOrganizacion = (int)filtro.IdOrganizacion;
                ucOrganizaciones.SetNombreOrganizacion(filtro.NombreOrganizacion);
            }
            else if (!string.IsNullOrEmpty(filtro.NombreOrganizacion))
                ucOrganizaciones.SetNombreOrganizacion(filtro.NombreOrganizacion);

            if (filtro.Paginacion != null)
                gridPaginacion.Paginacion = filtro.Paginacion;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarFiltro()", ex);
            _MensajeError = "Ha ocurrido un error al establecer el filtro de la página";
            throw;
        }
    }
    /// <summary>
    /// Procedimiento que cambia el sentido de la ordenación
    /// </summary>
    private string GetSortDirection(string sortExpression)
    {
        if (SortExpression == sortExpression)
        {
            if (SortDirection == PaginacionCls.Asc)
                SortDirection = PaginacionCls.Desc;
            else if (SortDirection == PaginacionCls.Desc)
                SortDirection = PaginacionCls.Asc;
            return SortDirection;
        }
        else
        {
            SortExpression = sortExpression;
            SortDirection = PaginacionCls.Asc;
            return SortDirection;
        }
    }
    /// <summary>
    /// Exporta a Excel la lista de usuarios
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void imgbtnExcel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (gvGestionUsuarios.Rows.Count > 0)
            {
                PaginacionCls paginacion = gridPaginacion.Paginacion;
                GUAI.Ent.Clases.FiltroUsuarioCls filtro = SetFiltro();

                if (string.IsNullOrEmpty(paginacion.CampoOrdenacion))
                {
                    paginacion.CampoOrdenacion = "NOMBRE_COMPLETO";
                    SortExpression = "NOMBRE_COMPLETO";
                    paginacion.Orden = PaginacionCls.Asc;
                    SortDirection = PaginacionCls.Asc;
                }
                filtro.CampoOrdenacion = paginacion.CampoOrdenacion;
                filtro.Orden = (paginacion.Orden == PaginacionCls.Asc) ? GUAI.Recursos.Tipos.eTipoOrdenacion.ASC : GUAI.Recursos.Tipos.eTipoOrdenacion.DESC;
                gvExcel.DataSource = NegocioPersona.GetPersonasFiltro(filtro);
                gvExcel.DataBind();
                ExportarGridViewGenerico("Usuarios", gvExcel);
            }
            else
                MostrarAlertError("No hay registros que exportar a Excel", "Atención", tipoAlert.warning);
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + "imgbtnExcel_Click()", ex);
            MostrarAlertError("Se ha producido un error al exportar los datos a Excel");
        }
    }
    #endregion
}

