﻿/// <summary>
/// controla el detalle de usuario para poder dar de alta, modificar o eliminar usuarios. También permite asignar o quitar perfiles a los usuarios
/// </summary>
public partial class RAEE_Administracion_DetalleUsuario : PageBase
{
 
}