﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using GUAI.Ent.Clases;
using System.Data;
using RAEE.Comun.Clases;

/// <summary>
/// Muestra el detalle de un usuario. Si la propiedad Modo está puesta como editable, se cargarán los datos de un usuario para que pueda ser editado. Si está puesta como Nuevo, el formulario aparecerá vacío
/// </summary>
public partial class UI_Administracion_Controles_Usuario : System.Web.UI.UserControl
{
    /// <summary>
    /// Enumeracion de los modos de visualización
    /// - Nuevo: Formulario para crear un usuario
    /// - Editable: Formulario para modificar un usuario
    /// </summary>
    public enum ModosVisualizacion
    {
        Nuevo,
        Editable,
        ModificarExtranet
    }

    #region Propiedades
    #region privadas
    /// <summary>
    /// Identificador de persona por defecto. Si es menor que 0 se trata de una nueva persona
    /// </summary>
    private long _idPersona = -1;
    /// <summary>
    /// Login actual del usuario cargado
    /// </summary>
    private string _login = string.Empty;
    /// <summary>
    /// Mensaje de error generado
    /// </summary>
    private string _MensajeError = string.Empty;
    /// <summary>
    /// Página base en la que se encuentra la página actual
    /// </summary>
    private PageBase _Page { get { return Page as PageBase; } }
    /// <summary>
    /// Indica si la página viene desde la gestión de usuario o desde el alta de usuarios
    /// </summary>
    private ModosVisualizacion _modo = ModosVisualizacion.Nuevo;
    /// <summary>
    /// Referencia a la clase NegPersona de IGUAI
    /// </summary>
    private GUAI.Neg.NegPersona _negocioPers;
    /// <summary>
    /// Referencia a la clase NegPersona de IGUAI
    /// </summary>
    private GUAI.Neg.NegPersona NegocioPers
    {
        get
        {
            if (_negocioPers == null)
                _negocioPers = new GUAI.Neg.NegPersona();
            return _negocioPers;
        }
    }
    /// <summary>
    /// Referencia a la clase NegGestionPermisos de IGUAI
    /// </summary>
    private GUAI.Neg.NegGestionPermisos _negocioPermiso;
    /// <summary>
    /// Referencia a la clase NegGestionPermisos de IGUAI
    /// </summary>
    private GUAI.Neg.NegGestionPermisos NegocioPermiso
    {
        get
        {
            if (_negocioPermiso == null)
                _negocioPermiso = new GUAI.Neg.NegGestionPermisos();
            return _negocioPermiso;
        }
    }
    #endregion

    #region públicas
    /// <summary>
    /// Propiedad de la expresión de la ordenación
    /// </summary>
    public string SortExpression
    {
        get { return (ViewState["SortExpression"] == null ? string.Empty : ViewState["SortExpression"].ToString()); }
        set { ViewState["SortExpression"] = value; }
    }
    /// <summary>
    /// Propiedad del sentido de la ordenación
    /// </summary>
    public string SortDirection
    {
        get { return (ViewState["SortDirection"] == null ? string.Empty : ViewState["SortDirection"].ToString()); }
        set { ViewState["SortDirection"] = value; }
    }
    /// <summary>
    /// Identificador de la persona de la que se desea modificar los datos y/o perfiles
    /// </summary>
    public long IdPersona
    {
        get
        {
            if (_idPersona < 1)
                if (Session["IdPersonaDetalle"] != null && !string.IsNullOrEmpty(Session["IdPersonaDetalle"].ToString()))
                    _idPersona = long.Parse(Session["IdPersonaDetalle"].ToString());
            return _idPersona;
        }
        set
        {
            Session["IdPersonaDetalle"] = value;
            _idPersona = value;
        }
    }
    /// <summary>
    /// Login actual del usuario cargado
    /// </summary>
    public string Login
    {
        get
        {
            if (string.IsNullOrEmpty(_login))
                if (Session["LoginUsuario"] != null && !string.IsNullOrEmpty(Session["LoginUsuario"].ToString()))
                    _login = Session["LoginUsuario"].ToString();
            return _login;
        }
        set
        {
            Session["LoginUsuario"] = value;
            _login = value;
        }
    }
    /// <summary>
    /// Indica si la página viene desde la gestión de usuario o desde el alta de usuarios
    /// </summary>
    public ModosVisualizacion Modo
    {
        get
        {
            return _modo;
        }
        set
        {
            _modo = value;
        }
    }
    #endregion
    #endregion

    #region Eventos
    /// <summary>
    /// Evento generado al cargar la página
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                if (Modo == ModosVisualizacion.Nuevo)
                {
                    LimpiarSesion();
                    ucOrganizaciones.Limpiar();
                    _idPersona = -1;
                }
                else if (Modo == ModosVisualizacion.ModificarExtranet)
                {
                    btnGuardar.Text = "Modificar datos";
                    btnGuardar.ToolTip = "Modifica los datos del usuario";
                    ltTitulo.Text = "Modificar datos del usuario";
                    CargarPersona();
                    formPerfiles.Visible = false;
                    btnCancelar.Visible = false;
                }
                CargarTipoDocumento();
            }

            if (Modo != ModosVisualizacion.ModificarExtranet)
            {
                if (IdPersona > 0)
                {
                    formPerfiles.Visible = true;
                    btnGuardar.Text = "Modificar datos";
                    btnGuardar.ToolTip = "Modifica los datos del usuario";
                    if (Modo == ModosVisualizacion.Editable) ltTitulo.Text = "Modificar usuario";
                    if (!Page.IsPostBack)
                    {
                        CargarPersona();
                        CargarGrupoUsuario();
                        CargarGrid();
                    }
                    if (string.IsNullOrEmpty(ddGrupoUsuario.SelectedValue))
                    {
                        ucOrganizaciones.Limpiar();
                        ucOrganizaciones.Habilitado = false;
                        ddPerfil.Enabled = false;
                    }
                    else
                    {
                        if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                        {
                            ucOrganizaciones.IdOrganizacion = (int)_Page.MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion;
                            ucOrganizaciones.Habilitado = false;
                        }
                        else
                        {
                            ucOrganizaciones.Habilitado = true;
                            ucOrganizaciones.IdGrupoUsuario = long.Parse(ddGrupoUsuario.SelectedValue);
                        }
                    }
                }
                else
                {
                    ucOrganizaciones.Limpiar();
                    formPerfiles.Visible = false;
                    btnPerfiles.Visible = false;
                    btnEliminar.Visible = false;
                    btnGuardar.Text = "Añadir usuario";
                    btnGuardar.ToolTip = "Da de alta un nuevo usuario";
                    ltTitulo.Text = "Nuevo usuario";
                    btnCancelar.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".Page_load()", ex);
            _Page.Error(_MensajeError);
        }
    }

    /// <summary>
    /// Guarda el usuario en GUAI con los datos proporcionados
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGuardarUsuario_Click(object sender, EventArgs e)
    {
        MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
        Page.Validate("RFUsuario");
        if (Page.IsValid)
        {
            //Si el formulario se ha rellenado correctamente, guardamos los datos del usuario
            if (!ComprobarFormulario())
                return;
            else
            {
                GUAI.Ent.Clases.Persona persona = new Persona();

                try
                {
                    string mensaje = string.Empty;
                    persona.Nombre = tbNombre.Text.Trim();
                    persona.Apellido1 = tbApellido1.Text.Trim();
                    persona.Apellido2 = tbApellido2.Text.Trim();
                    persona.Email = tbMail.Text.Trim();
                    persona.TipoDocumento = ddTipoDoc.SelectedValue;
                    //Si el tipo documento es NIF. Normalizamos el nif, para introducir ceros en la parte izquierda
                    if (persona.TipoDocumento.ToUpper().Trim() == "NIF")
                        tbDocumento.Text = DllUtils.Validaciones.NormalizarNif(tbDocumento.Text);
                    persona.NumeroDocumento = tbDocumento.Text.Trim();
                    persona.Usuario = tbLogin.Text.ToUpper().Trim();
                    persona.Observaciones = tbObservaciones.Value;

                    if (IdPersona > 0)//Se modifica la persona
                    {
                        persona.IdPersona = IdPersona;
                        NegocioPers.ModificarPersona(persona);
                    }
                    else //Es un usuario nuevo
                    {
                        //Se comprueba que no exista en GUAI
                        GUAI.Ent.Clases.Persona personaGuai = NegocioPers.ExistePersona(persona.TipoDocumento, persona.NumeroDocumento);
                        if (personaGuai == null)
                        {
                            IdPersona = NegocioPers.AltaPersona(persona);
                            if ((System.Configuration.ConfigurationManager.AppSettings.Get("entorno") == "PRODUCCION") || (System.Configuration.ConfigurationManager.AppSettings.Get("entorno") != "PRODUCCION" && RAEE.Neg.CorreosNeg.ValidaEmail(persona.Email)))
                            {
                                if (NegocioPers.EnviarContrasenia(IdPersona) < 0)
                                    mensaje = " No se ha podido realizar el envío de la contraseña al usuario";
                            }
                            else
                                mensaje = " No se ha podido realizar el envío de la contraseña al usuario. Correo no autorizado a envío.";
                        }
                        else
                            NegocioPers.ModificarPersona(persona);
                    }
                    if (Modo != ModosVisualizacion.ModificarExtranet)
                    {
                        btnNuevoPerfil.Enabled = true;
                        formPerfiles.Visible = true;
                        btnGuardar.Text = "Modificar datos";
                        btnGuardar.ToolTip = "Modifica los datos del usuario";
                        MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "Se han almacenado correctamente los datos del usuario." + mensaje);
                        CargarGrupoUsuario();
                        CargarGrid();
                    }
                    else
                        MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "Se han almacenado correctamente los datos del usuario." + mensaje);
                }
                catch (Exception ex)
                {
                    MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnGuardarUsuario(IdPersona: " + IdPersona.ToString() + ")", ex);
                    MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "Error al actualizar los datos del usuario en el sistema. " + _MensajeError);
                }
            }
        }
    }

    /// <summary>
    /// Elimina el usuario. Elimina todos sus permisos de GUAI para la aplicación
    /// </summary>
    protected void btnEliminarUsuario_Click(object sender, EventArgs e)
    {
        MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
        try
        {
            if (IdPersona == _Page.MasterBase.DatosSesionLogin.Perfil.Persona.IdPersona)
                MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "El usuario no puede borrarse a sí mismo");
            else
            {
                if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                {
                    List<PersonaOrganizacion> listaPermisos = NegocioPermiso.GetPersonaOrganizaciones(IdPersona, _Page.MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion, new List<long>() { RAEE.Comun.TipoDatos.Aplicacion });
                    PersonaOrganizacion usuario = listaPermisos.Find(delegate(PersonaOrganizacion user) { return user.Perfil.IdPerfil == 1; });
                    if (usuario != null)
                    {
                        MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se puede borrar el usuario porque tiene permisos de administración para la aplicación");
                        return;
                    }
                    else
                        NegocioPermiso.BorrarPerfilesPersona(IdPersona, new List<long>() { RAEE.Comun.TipoDatos.Aplicacion }, _Page.MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion);
                }
                else
                    NegocioPermiso.BorrarPerfilesPersona(IdPersona, new List<long>() { RAEE.Comun.TipoDatos.Aplicacion }, null);

                LimpiarSesion();
                _Page.MostrarAlertError("El usuario se han eliminado correctamente de la aplicación.", "Confirmación", PageBase.tipoAlert.success, _Page.MasterBase.RelativeURL + "UI/Administracion/GestionUsuarios.aspx?grid=S");
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnEliminarUsuario_Click(IdPersona: " + IdPersona.ToString() + ")", ex);
            MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se ha podido eliminar el usuario. " + _MensajeError);
        }
    }

    /// <summary>
    /// Regenera la contraseña de la persona y envía un correo con sus credenciales
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRegenerar_Click(object sender, EventArgs e)
    {
        try
        {
            MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);

            bool realizarEnvio = true;
            if (System.Configuration.ConfigurationManager.AppSettings.Get("entorno") != "PRODUCCION")
            {
                //Obtenemos el email de la persona
                GUAI.Ent.Clases.Persona persona = NegocioPers.GetDatosPersona(IdPersona);
                if (persona != null)
                    realizarEnvio = RAEE.Neg.CorreosNeg.ValidaEmail(persona.Email);
            }

            int resultado = 0;
            if (realizarEnvio)
                resultado = NegocioPers.RegenerarContrasenia(IdPersona);

            if (resultado < 1)
                MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "Se ha regenerado correctamente la contraseña, pero se ha producido un error en el envío de correo a la persona con sus credenciales");
            else
                MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "Se ha regenerado correctamente la contraseña");
            return;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnRegenerar_Click(IdPersona:" + IdPersona.ToString() + ")", ex);
            MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se ha podido regenerar la contraseña del usuario");
        }
    }

    /// <summary>
    /// Evento lanzado cuando se pulsa sobre enviar lista de perfiles. Envía un correo a la persona con los permisos que tiene en las aplicaciones
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEnviar_Click(object sender, EventArgs e)
    {
        try
        {
            MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
            if (NegocioPermiso.EnviarCredenciales(IdPersona, string.Empty))
                MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "Se ha realizado el envío de la lista de perfiles correctamente");
            else
                MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "Fallo en el envío. Se ha producido un error en el envío de la lista de perfiles");
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + "btnEnviar_Click(IdPersona: " + IdPersona.ToString() + ")", ex);
            MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se han podido enviar la lista de perfiles al usuario");
        }
    }

    /// <summary>
    /// Cuando se introduce un login, se comprueba que no exista ya un usuario con dicho login. Es único
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void tbLogin_TextChanged(object sender, EventArgs e)
    {
        try
        {
            MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
            //comprobamos si el login es único
            bool Existe = false;
            if (Login != tbLogin.Text) Existe = NegocioPers.ExisteLogin(_idPersona, tbLogin.Text.ToUpper());
            if (Existe)
            {
                tbLogin.Text = string.Empty;
                MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "El login introducido ya se encuentra en uso, por favor seleccione otro");
                tbLogin.Focus();
            }
            else
                tbApellido1.Focus();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".tbLogin_TextChanged(Login: " + tbLogin.Text + ")", ex);
            _Page.Error("Se ha producido un error al comprobar el usuario");
        }
    }

    /// <summary>
    /// Evento generado cuando se pulsa en Agregar perfil. Añade el perfil al usuario y realiza el envío de correo con la lista de perfiles
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnNuevoPerfil_Click(object sender, EventArgs e)
    {
        MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
        Page.Validate("RFPerfil");
        if (Page.IsValid)
        {
            try
            {
                MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
                List<GUAI.Ent.Clases.PersonaOrganizacion> permisos = new List<PersonaOrganizacion>();
                GUAI.Ent.Clases.PersonaOrganizacion nuevoPerfil;

                nuevoPerfil = new PersonaOrganizacion();
                nuevoPerfil.IdAplicacion = _Page.MasterBase.DatosSesionLogin.Perfil.IdAplicacion;
                nuevoPerfil.Organizacion.IdOrganizacion = ucOrganizaciones.IdOrganizacion;
                nuevoPerfil.GrupoUsuario.IdGrupoUsuario = long.Parse(ddGrupoUsuario.SelectedValue);
                nuevoPerfil.Perfil.IdPerfil = long.Parse(ddPerfil.SelectedValue);
                permisos.Add(nuevoPerfil);

                List<PersonaOrganizacion> permisosExistentes = NegocioPermiso.GetPersonaOrganizaciones(IdPersona, ucOrganizaciones.IdOrganizacion, new List<long> { _Page.MasterBase.DatosSesionLogin.Perfil.IdAplicacion });
                bool existePermiso = false;
                if (permisosExistentes != null && permisosExistentes.Count > 0)
                    foreach (PersonaOrganizacion perm in permisosExistentes)
                        if (perm.GrupoUsuario.DescGrupoUsuario == ddGrupoUsuario.SelectedItem.Text)
                        {
                            existePermiso = true;
                            break;
                        }
                if (existePermiso)
                {
                    MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "El permiso no puede darse de alta. El usuario ya tiene un permiso para la organización del grupo usuario indicado");
                    return;
                }

                NegocioPermiso.AltaPersonaOrganizacion(IdPersona, permisos);

                //recuperamos los datos de la persona
                GUAI.Ent.Clases.Persona persona = NegocioPers.GetDatosPersona(IdPersona);
                //Enviamos correo, cuando se añaden nuevos perfiles, que no sean de Intranet
                //Pero no enviamos contraseña.                        
                if (NegocioPermiso.EnviarCredenciales(IdPersona, string.Empty))
                    MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "Se han almacenado correctamente los permisos para el usuario");
                else
                    MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "Se han almacenado correctamente los permisos para el usuario. Se ha producido un error en el envío de la lista de perfiles");
                CargarGrid();
                ddGrupoUsuario.ClearSelection();

                if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                    CargarGrupoUsuario();
                else
                {
                    ddPerfil.Items.Clear();
                    ddPerfil.Enabled = false;
                }
                ucOrganizaciones.Limpiar();
                ucOrganizaciones.Habilitado = false;
            }
            catch (Exception ex)
            {
                MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".btnNuevoPerfil_Click() ID Persona: " + IdPersona.ToString(), ex);
                MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se ha podido dar de alta el permiso solicitado para el usuario. " + _MensajeError);
            }
        }
    }

    /// <summary>
    /// Evento generado cuando se selecciona un grupo de usuario. Se carga la lista de organizaciones vinculadas y la lista de perfiles
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddGrupoUsuario_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);

            ucOrganizaciones.Limpiar();
            ddPerfil.Items.Clear();
            if (!string.IsNullOrEmpty(ddGrupoUsuario.SelectedValue))
            {
                ddPerfil.Enabled = true;
                ucOrganizaciones.Habilitado = true;
                CargarOrganizaciones();
                CargarPerfiles();
            }
            else
            {
                ucOrganizaciones.Habilitado = false;
                ddPerfil.Enabled = false;
            }
            ddGrupoUsuario.Focus();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".ddGrupoUsuario_SelectedIndex()", ex);
            _Page.Error(_MensajeError);
        }
    }

    /// <summary>
    /// Comprueba que cuando se cambie el tipo de documento y numero de documento, no exista un usuario con esos nuevos datos.
    /// En caso de que exista un usuario con esos datos, se cargan los datos del usuario encontrado.
    /// </summary>      
    protected void ComprobarUsuarioExistente(object sender, EventArgs e)
    {
        try
        {
            string TipoDocumento = ddTipoDoc.SelectedValue;
            string NumDocumento = tbDocumento.Text.Trim();

            // Si se ha introducido tipo documento y numero de documento
            if (!string.IsNullOrEmpty(TipoDocumento) && !string.IsNullOrEmpty(NumDocumento))
            {
                GUAI.Ent.Clases.Persona persona = new Persona();

                //Si el tipo documento es NIF. Normalizamos el nif, para introducir ceros en la parte izquierda
                if (TipoDocumento.ToUpper().Trim() == "NIF")
                    NumDocumento = DllUtils.Validaciones.NormalizarNif(NumDocumento);

                persona = NegocioPers.ExistePersona(TipoDocumento, NumDocumento);

                //Se ha encontrado una persona con ese tipo y numero de documento
                if (persona != null)
                {
                    btnGuardar.Text = "Modificar datos";
                    btnGuardar.ToolTip = "Modifica los datos del usuario";
                    ltTitulo.Text = "Modificar usuario";
                    //Cargamos sus datos en los controles correspondientes
                    tbNombre.Text = persona.Nombre;
                    tbApellido1.Text = persona.Apellido1;
                    tbApellido2.Text = persona.Apellido2;
                    ddTipoDoc.SelectedValue = persona.TipoDocumento;
                    tbDocumento.Text = persona.NumeroDocumento;
                    tbLogin.Text = persona.Usuario;
                    tbMail.Text = persona.Email;
                    tbObservaciones.Value = persona.Observaciones;

                    IdPersona = persona.IdPersona;

                    //Si estamos en extranet, deshabilitamos los controles para que no puedan modificarlos
                    if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                    {
                        tbNombre.Enabled = false;
                        tbApellido1.Enabled = false;
                        tbApellido2.Enabled = false;
                        ddTipoDoc.Enabled = false;
                        tbDocumento.Enabled = false;
                        tbLogin.Enabled = false;
                        tbMail.Enabled = false;
                        tbObservaciones.Disabled = true;
                        btnGuardar.Visible = false;
                    }

                    CargarGrupoUsuario();
                    CargarGrid();
                    formPerfiles.Visible = true;
                }
                else
                    tbNombre.Focus();
            }
            else if (sender.GetType() == typeof(System.Web.UI.HtmlControls.HtmlInputText))
                tbNombre.Focus();
            else
                ddTipoDoc.Focus();

        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".ComprobarUsuarioExistente(). Tipo documento: " + ddTipoDoc.SelectedValue + " Número documento: " + tbDocumento.Text, ex);
            _Page.Error(_MensajeError);
        }
    }

    /// <summary>
    /// Evento generado al pulsar sobre el botón cancelar. Limpia las variable de sesión utilizadas y vuelve a la página de gestión
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancelar_Click(object sender, EventArgs e)
    {
        LimpiarSesion();
        Response.Redirect("GestionUsuarios.aspx?grid=S", false);
    }

    /// <summary>
    /// Comprueba que el campo observaciones no supere los 250 caracteres
    /// </summary>
    /// <param name="source"></param>
    /// <param name="args"></param>
    protected void cvtbObservaciones_ServerValidate1(object source, ServerValidateEventArgs args)
    {
        args.IsValid = (args.Value.Length >= 250);
    }

    #endregion

    #region Eventos del grid
    /// <summary>
    /// Evento lanzado cuando se pulsa en ordenar las columnas del grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvDetalleUsuario_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            SortDirection = GetSortDirection(e.SortExpression).Equals("Ascending") ? PaginacionCls.Asc : PaginacionCls.Desc;
            SortExpression = e.SortExpression;
            CargarGrid();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".gvDetalleUsuario_Sorting()", ex);
            _Page.Error(_MensajeError);
        }
    }

    /// <summary>
    /// Evento lanzado cuando se pulsa sobre el icono de eliminar perfil
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvDetalleUsuario_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (gvDetalleUsuario.Rows.Count > 0)
                switch (e.CommandName)
                {
                    case "Eliminar":

                        MostrarMensaje(RAEE.Comun.Log.TipoError.Limpiar, string.Empty);
                        //Recuperamos los argumentos de la fila
                        string[] fila = e.CommandArgument.ToString().Split(',');
                        long idOrganizacion = long.Parse(fila[0]);
                        long idGrupoUsuario = long.Parse(fila[1]);
                        string gestiona = fila[2];
                        int idApp = int.Parse(fila[3]);

                        if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Intranet.GetHashCode().ToString())
                        {
                            // En intranet,  un usuario no se puede borrar sus propios permisos de administrador.
                            //Comprobamos si el usuario al que se quieren quitar permisos es el propio usuario
                            if (_Page.MasterBase.DatosSesionLogin.Perfil.Persona.IdPersona == IdPersona)
                            {
                                // Si gestiona usuarios, es que se trata de un usuario administrador, entonces no puede borrarse sus propios permisos de administrador.
                                if (gestiona == GUAI.Recursos.Tipos.EnumSiNo.SI.ToString())
                                {
                                    // Es MINISTERIO y no se puede borrar sus propios permisos
                                    if (idOrganizacion == 1)
                                        MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "El usuario no puede eliminar sus propios permisos de administración");
                                    else
                                    {
                                        // Se permite borrar los permisos de administrador para EXTRANET                                    
                                        NegocioPermiso.BorrarGrupoUsuarioPersona(IdPersona, idOrganizacion, idGrupoUsuario);
                                        MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "El permiso del usuario se ha eliminado correctamente");
                                    }
                                }
                                else
                                {
                                    //Como no es el propio usuario, borramos el permiso solicitado                                    
                                    NegocioPermiso.BorrarGrupoUsuarioPersona(IdPersona, idOrganizacion, idGrupoUsuario);
                                    MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "El permiso del usuario se ha eliminado correctamente");
                                }
                            }
                            else
                            {
                                if (_Page.MasterBase.DatosSesionLogin.Perfil.Perfil.IdPerfil == 1 && _Page.MasterBase.DatosSesionLogin.Perfil.GrupoUsuario.Codigo == "GTR")
                                {
                                    //Como no es el propio usuario, borramos el permiso solicitado solo si es Administrador y Gestor de esa aplicacion                                   
                                    NegocioPermiso.BorrarGrupoUsuarioPersona(IdPersona, idOrganizacion, idGrupoUsuario);
                                    MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "El permiso del usuario se ha eliminado correctamente");
                                }
                                else
                                    MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No ha sido posible borrar el permiso del usuario debido a que no es administrador");
                            }
                        }
                        else
                        {
                            //En extranet, un usuario administrador no puede borrar perfiles de administrador de otros usuarios.
                            if (gestiona == GUAI.Recursos.Tipos.EnumSiNo.SI.ToString())
                                MostrarMensaje(RAEE.Comun.Log.TipoError.Error, "No se permite la eliminación de permisos de administración");
                            else
                            {
                                //Como el usuario que se pretende borrar no es administrador, permitimos el borrado                                 
                                NegocioPermiso.BorrarGrupoUsuarioPersona(IdPersona, idOrganizacion, idGrupoUsuario);
                                MostrarMensaje(RAEE.Comun.Log.TipoError.Success, "El permiso del usuario se ha eliminado correctamente");
                            }
                        }

                        //Cargamos la grid de nuevo para que desaparezca el usuario borrado
                        CargarGrid();
                        break;
                }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + "gvDetalleUsuario_RowCommand().", ex);
            _Page.Error(_MensajeError);
        }
    }

    /// <summary>
    /// Evento lanzado cuando se pinta las filas del grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvDetalleUsuario_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.background='#FFF0A2'");
                e.Row.Attributes.Add("onmouseout", "this.style.background='#FFFFFF'");
            }
            if (e.Row.RowType == DataControlRowType.Header)
            {
                string[] auxValores = new string[3] { "TIPO_DOC_ORG || NUMERO_DOC_ORG", "NOMBRE_ORG", "GRUPO_USUARIOS" };

                string[] auxTooltip = new string[3] { "Ordena por el número de documento de la organización", "Ordena por el nombre de la organización", "Ordena por el grupo usuario-perfil asociado" };
                for (int i = 0; i < auxValores.Length; i++)
                {
                    if (SortExpression.ToUpper().Trim() == auxValores[i])
                    {
                        using (System.Web.UI.HtmlControls.HtmlGenericControl span = new System.Web.UI.HtmlControls.HtmlGenericControl())
                        {
                            if (SortDirection == PaginacionCls.Asc)
                                span.Attributes["class"] = "glyphicon glyphicon-arrow-up";
                            else
                                span.Attributes["class"] = "glyphicon glyphicon-arrow-down";

                            span.Attributes["aria-hidden"] = "true";
                            span.ID = "ico1";
                            // Añadir icono a la cabecera
                            e.Row.Cells[i + 1].Controls.AddAt(0, span);
                        }
                    }
                    e.Row.Cells[i + 1].ToolTip = auxTooltip[i];
                }
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + "gvDetalleUsuario_RowCommand().", ex);
            _Page.Error(_MensajeError);
        }
    }

    #endregion

    #region Métodos privados
    /// <summary>
    /// Transforma la lista de permisos devueltos en una tabla correspondiente al grid
    /// </summary>
    /// <param name="listaPermisos">Lista de permisos que tiene el usuario</param>
    /// <returns>Tabla adaptada al contenedor del grid</returns>
    private DataTable AdaptarTabla(List<PersonaOrganizacion> listaPermisos)
    {
        try
        {
            DataTable resultado = new DataTable();
            resultado.Columns.Add("ID_PERSONA");
            resultado.Columns.Add("ID_APP");
            resultado.Columns.Add("APLICACION");
            resultado.Columns.Add("IDORGANIZACION");
            resultado.Columns.Add("NOMBRE_ORG");
            resultado.Columns.Add("IDGRUPOUSUARIO");
            resultado.Columns.Add("GRUPO_USUARIOS");
            resultado.Columns.Add("CERTIFICADO_OBLIGATORIO");
            resultado.Columns.Add("GESTIONAUSUARIOS");
            resultado.Columns.Add("DOCUMENTO");
            resultado.Columns.Add("ACTIVO");

            DataRow fila;
            foreach (PersonaOrganizacion persOrg in listaPermisos)
            {
                fila = resultado.NewRow();
                fila.BeginEdit();
                fila["ID_PERSONA"] = persOrg.Persona.IdPersona.ToString();
                fila["ID_APP"] = persOrg.IdAplicacion;
                fila["APLICACION"] = persOrg.Aplicacion;
                fila["IDORGANIZACION"] = persOrg.Organizacion.IdOrganizacion.ToString();
                fila["NOMBRE_ORG"] = persOrg.Organizacion.Nombre;
                fila["IDGRUPOUSUARIO"] = persOrg.GrupoUsuario.IdGrupoUsuario.ToString();
                fila["GRUPO_USUARIOS"] = persOrg.GrupoUsuario.DescGrupoUsuario + " - " + persOrg.Perfil.Descripcion;
                fila["CERTIFICADO_OBLIGATORIO"] = persOrg.Perfil.CertificadoObligatorio.ToString();
                fila["GESTIONAUSUARIOS"] = persOrg.Perfil.GestionaUsuarios.ToString();
                fila["DOCUMENTO"] = persOrg.Organizacion.TipoDocumento + ": " + persOrg.Organizacion.NumeroDocumento;
                fila["ACTIVO"] = persOrg.Organizacion.Activa;
                fila.EndEdit();
                resultado.Rows.Add(fila);
                resultado.AcceptChanges();
            }

            DataView tablaOrdenada = resultado.DefaultView;

            return tablaOrdenada.Table;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".AdaptarTabla()", ex);
            throw;
        }
    }

    /// <summary>
    /// Carga el combo de tipo documento para los datod del usuario
    /// </summary>
    private void CargarTipoDocumento()
    {
        try
        {
            DllUtils.CodigosInadm codigos = new DllUtils.CodigosInadm();
            DataTable dt = new DataTable();
            dt = codigos.GetTiposDoc();

            System.Data.DataView dv = dt.DefaultView;
            dv.Sort = "CTIPO_DOC ASC";

            ddTipoDoc.DataSource = dv;
            ddTipoDoc.DataBind();

            //añado como primer elemento texto
            ddTipoDoc.Items.Insert(0, new ListItem("Elija una opción", ""));
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarTipoDocumento()", ex);
            _MensajeError = "Error al cargar los tipos de documento";
            throw;
        }
    }

    /// <summary>
    /// Carga los perfiles del usuario
    /// </summary>
    private void CargarGrid()
    {
        try
        {
            GUAI.Comun.PaginacionCls filtro = new GUAI.Comun.PaginacionCls();

            if (string.IsNullOrEmpty(SortExpression))
            {
                SortExpression = "TIPO_DOC_ORG || NUMERO_DOC_ORG";
                SortDirection = PaginacionCls.Asc;
            }
            if (string.IsNullOrEmpty(SortDirection))
                SortDirection = PaginacionCls.Asc;


            filtro.CampoOrdenacion = SortExpression;
            filtro.Orden = (SortDirection == PaginacionCls.Asc) ? GUAI.Recursos.Tipos.eTipoOrdenacion.ASC : GUAI.Recursos.Tipos.eTipoOrdenacion.DESC;

            List<PersonaOrganizacion> listaPermisos = new List<PersonaOrganizacion>();

            if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
                listaPermisos = NegocioPermiso.GetPersonaOrganizaciones(IdPersona, _Page.MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion, new List<long>() { RAEE.Comun.TipoDatos.Aplicacion }, filtro);
            else
                listaPermisos = NegocioPermiso.GetPersonaOrganizaciones(IdPersona, null, new List<long>() { RAEE.Comun.TipoDatos.Aplicacion }, filtro);

            btnRegenerar.Visible = false;
            if (listaPermisos != null)
            {
                if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Intranet.GetHashCode().ToString())
                    btnRegenerar.Visible = true;
                btnPerfiles.Visible = true;
                btnEliminar.Visible = true;
                DataTable dtPermisos = AdaptarTabla(listaPermisos);
                gvDetalleUsuario.DataSource = dtPermisos;
            }
            else
            {
                btnPerfiles.Visible = false;
                btnEliminar.Visible = false;
                gvDetalleUsuario.DataSource = null;
            }            
            gvDetalleUsuario.DataBind();
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarGrid(); Id Persona: " + IdPersona.ToString(), ex);
            _MensajeError = "Error al cargar el listado de permisos";
            throw;
        }
    }

    /// <summary>
    /// Carga los datos del usuario
    /// </summary>
    private void CargarPersona()
    {
        if (IdPersona > 0)
        {
            try
            {
                Persona usuario = new Persona();
                usuario = NegocioPers.GetDatosPersona(IdPersona);
                if (usuario != null)
                {
                    tbNombre.Text = usuario.Nombre;
                    tbApellido1.Text = usuario.Apellido1;
                    tbApellido2.Text = usuario.Apellido2;
                    ddTipoDoc.SelectedValue = usuario.TipoDocumento;
                    tbDocumento.Text = usuario.NumeroDocumento;
                    tbObservaciones.Value = usuario.Observaciones;
                    tbMail.Text = usuario.Email;
                    tbLogin.Text = usuario.Usuario;
                    Login = usuario.Usuario;
                }
                else
                    throw new Exception("No se ha recuperado ningún valor en BD de GUAI para el usuario " + IdPersona.ToString());
                if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString()) //Se deshabilitan todos los campos para que no los pueda cambiar
                {
                    ddTipoDoc.Enabled = false;
                    tbDocumento.Enabled = false;
                    if (Modo != ModosVisualizacion.ModificarExtranet)
                    {
                        tbNombre.Enabled = false;
                        tbApellido1.Enabled = false;
                        tbApellido2.Enabled = false;
                        tbObservaciones.Disabled = true;
                        tbMail.Enabled = false;
                        tbLogin.Enabled = false;
                        btnGuardar.Visible = false;
                    }
                    else
                        btnEliminar.Visible = false;

                }
            }
            catch (Exception ex)
            {
                MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarPersona(IdPersona: " + IdPersona.ToString() + ")", ex);
                _MensajeError = "No se han podido cargar en este momento los datos del usuario indicado.";
                throw;
            }
        }
    }

    /// <summary>
    /// Comprueba que se hayan introducido en el formulario todos los datos obligatorios
    /// </summary>
    /// <returns>True si están todos los datos válidamente rellenos y false en caso contrario</returns>
    private bool ComprobarFormulario()
    {
        try
        {
            bool correcto = false;
            bool resultado = false;

            if (!string.IsNullOrEmpty(tbNombre.Text) &&
                !string.IsNullOrEmpty(tbApellido1.Text) &&
                ddTipoDoc.SelectedIndex != 0 &&
                !string.IsNullOrEmpty(tbDocumento.Text) &&
                !string.IsNullOrEmpty(tbLogin.Text) &&
                !string.IsNullOrEmpty(tbMail.Text))
                correcto = true;
            else
            {
                MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "Debe rellenar todos los campos obligatorios para poder guardar los datos del usuario");
                return false;
            }

            //Comprobamos el formato del correo electrónico
            resultado = DllUtils.Validaciones.ValidaEmail(tbMail.Text);
            if (!resultado)
            {
                MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "El correo electrónico introducido no tiene un formato correcto");
                tbMail.Focus();
                return false;
            }
            else
                correcto = true;

            //Comprobamos el documento
            resultado = false;
            resultado = DllUtils.Validaciones.ValidarDocumento(tbDocumento.Text, ddTipoDoc.SelectedValue);
            if (!resultado)
            {
                MostrarMensaje(RAEE.Comun.Log.TipoError.Warning, "El tipo de documento y número de documentos introducidos no son válidos");
                tbDocumento.Focus();
                return false;
            }
            else
                correcto = true;

            return correcto;
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".ComprobarFormulario()", ex);
            _MensajeError = "Error al validar el formulario";
            throw;
        }
    }

    /// <summary>
    /// Carga el combo "Perfil" la lista de perfiles en función de grupo usuario seleccionado
    /// </summary>
    private void CargarPerfiles()
    {
        try
        {
            List<Perfil> perfiles = NegocioPermiso.GetPerfiles(long.Parse(ddGrupoUsuario.SelectedValue));

            if (perfiles != null && perfiles.Count > 0)
            {
                DataTable resultado = new DataTable();
                resultado.Columns.Add("ID_PERFIL");
                resultado.Columns.Add("DESCRIPCION");

                DataRow fila;
                foreach (Perfil perfil in perfiles)
                {
                    fila = resultado.NewRow();
                    fila.BeginEdit();
                    fila["ID_PERFIL"] = perfil.IdPerfil.ToString();
                    fila["DESCRIPCION"] = perfil.Descripcion;
                    fila.EndEdit();
                    resultado.Rows.Add(fila);
                    resultado.AcceptChanges();
                }

                ddPerfil.DataSource = resultado;
                ddPerfil.DataBind();
            }
            ddPerfil.Items.Insert(0, new ListItem("Elija una opción", ""));
        }
        catch (Exception ex)
        {
            _MensajeError = "No se han podido cargar la lista de perfiles";
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarPerfiles(Grupo usuario: " + ddGrupoUsuario.SelectedValue + ")", ex);
            throw;
        }
    }

    /// <summary>
    /// Carga el combo "Grupo usuario" con la lista de grupos usuario de la aplicación
    /// </summary>
    private void CargarGrupoUsuario()
    {
        try
        {
            if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Intranet.GetHashCode().ToString())
            {
                DataTable resultado;
                resultado = NegocioPermiso.GetGruposUsuarioDatos(_Page.MasterBase.DatosSesionLogin.Perfil.IdAplicacion, null);
                if (resultado != null && resultado.Rows.Count > 0)
                {
                    ddGrupoUsuario.DataSource = resultado;
                    ddGrupoUsuario.DataBind();
                }
                ddGrupoUsuario.Items.Insert(0, new ListItem("Elija una opción", ""));
            }
            else
            {
                ddGrupoUsuario.Items.Insert(0, new ListItem(_Page.MasterBase.DatosSesionLogin.Perfil.GrupoUsuario.DescGrupoUsuario, _Page.MasterBase.DatosSesionLogin.Perfil.GrupoUsuario.IdGrupoUsuario.ToString()));
                ddGrupoUsuario.Enabled = false;
                ddPerfil.Enabled = true;
                CargarPerfiles();
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarGrupoUsuario()", ex);
            _MensajeError = "No se han podido cargar los grupos usuario";
            throw;
        }
    }

    /// <summary>
    /// Carga la lista de organizaciones 
    /// </summary>
    private void CargarOrganizaciones()
    {
        try
        {
            if (_Page.MasterBase.EntornoAcceso == RAEE.Comun.TipoDatos.Entorno.Extranet.GetHashCode().ToString())
            {
                ucOrganizaciones.IdOrganizacion = (int)_Page.MasterBase.DatosSesionLogin.Perfil.Organizacion.IdOrganizacion;
                ucOrganizaciones.Habilitado = false;
            }
            else
            {
                ucOrganizaciones.IdGrupoUsuario = long.Parse(ddGrupoUsuario.SelectedValue);
                ucOrganizaciones.Iniciar();
            }
        }
        catch (Exception ex)
        {
            MasterPageBase.TrazaLog.Error("Error en " + this.GetType().FullName + ".CargarOrganizaciones(). Grupo usuario: " + ddGrupoUsuario.SelectedValue, ex);
            _MensajeError = "No se han podido cargar la lista de organizaciones";
            throw;
        }
    }

    /// <summary>
    /// Muestra en pantalla el tipo de mensaje que se desee dar al usuario
    /// </summary>
    /// <param name="tipo">Tipo de mensaje a mostrar</param>
    /// <param name="mensaje">Mensaje que se le va a dar</param>
    private void MostrarMensaje(RAEE.Comun.Log.TipoError tipo, string mensaje)
    {
        switch (tipo)
        {
            case RAEE.Comun.Log.TipoError.Error:
                alertError.Visible = true;
                lbError.Text = mensaje;
                break;
            case RAEE.Comun.Log.TipoError.Warning:
                alertWarning.Visible = true;
                lbWarning.Text = mensaje;
                break;
            case RAEE.Comun.Log.TipoError.Success:
                alertSuccess.Visible = true;
                lbSuccess.Text = mensaje;
                break;
            case RAEE.Comun.Log.TipoError.Limpiar:
            default:
                alertSuccess.Visible = false;
                alertWarning.Visible = false;
                alertError.Visible = false;
                break;
        }
    }

    /// <summary>
    /// Limpia las variables de sesión utilizadas por la página
    /// </summary>
    private void LimpiarSesion()
    {
        Session.Remove("IdPersonaDetalle");
        Session.Remove("LoginUsuario");
        Session.Remove("IdOrganizacion");
    }

    /// <summary>
    /// Procedimiento que cambia el sentido de la ordenación
    /// </summary>
    private string GetSortDirection(string sortExpression)
    {
        if (SortExpression == sortExpression)
        {
            if (SortDirection == PaginacionCls.Asc)
                SortDirection = PaginacionCls.Desc;
            else if (SortDirection == PaginacionCls.Desc)
                SortDirection = PaginacionCls.Asc;
            return SortDirection;
        }
        else
        {
            SortExpression = sortExpression;
            SortDirection = PaginacionCls.Asc;
            return SortDirection;
        }
    }

    #endregion

}