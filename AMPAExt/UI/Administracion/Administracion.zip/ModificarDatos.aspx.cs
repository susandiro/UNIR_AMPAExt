﻿using System;
/// <summary>
/// controla el detalle de usuario para poder dar de alta, modificar o eliminar usuarios. También permite asignar o quitar perfiles a los usuarios
/// </summary>
public partial class RAEE_Administracion_ModificarDatos: PageBase
{
   /// <summary>
    /// Evento generado al cargar la página
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        detalleUsuario.IdPersona = MasterBase.DatosSesionLogin.Perfil.Persona.IdPersona;
    }
}