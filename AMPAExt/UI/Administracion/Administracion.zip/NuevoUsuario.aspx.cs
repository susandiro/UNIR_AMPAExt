﻿
/// <summary>
/// Representa la página para dar de alta a un usuario
/// </summary>
public partial class UI_Administracion_NuevoUsuario : PageBase
{
  
}